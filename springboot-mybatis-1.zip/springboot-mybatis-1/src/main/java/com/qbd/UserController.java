package com.qbd;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


//这个注解不能使用RestController，不然会返回模板类型的页面
@Controller
public class UserController {
	@RequestMapping("/index")
	public String index() {
		
		return "index";
	}
}
